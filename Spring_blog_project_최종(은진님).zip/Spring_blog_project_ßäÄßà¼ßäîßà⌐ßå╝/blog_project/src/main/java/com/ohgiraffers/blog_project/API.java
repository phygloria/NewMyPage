package com.ohgiraffers.blog_project;


//model 에 데이터를 담지 않고
//서비스와 컨트롤러 레이어를 기준으로 데이터를 전송한다(API 기반)

// API 기반 통신을 사용한다

// 백엔드 서버슬 API 로 두게 되면 -> 워치 사용 가능, 웹사이트, 테블릿 등 멀티디바이스에 대한 대응이 가능한다.
// @RestController
// @RequestMapping






public class API {
}
